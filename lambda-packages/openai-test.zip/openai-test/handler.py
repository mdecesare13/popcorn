import os
import json
import boto3
import random
from botocore.exceptions import ClientError
from openai import OpenAI
from decimal import Decimal
from ..common.logging_util import init_logger

logger = init_logger('openai-test')

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
secretsmanager = boto3.client('secretsmanager')

def get_openai_api_key():
    """Retrieve OpenAI API key from Secrets Manager."""
    try:
        secret_name = "popcorn/openai"
        response = secretsmanager.get_secret_value(SecretId=secret_name)
        return response['SecretString']
    except ClientError as e:
        logger.error(f"Error getting secret: {str(e)}")
        raise

def get_random_movie():
    """Get a random movie from DynamoDB."""
    try:
        table = dynamodb.Table('popcorn-movies')
        
        # Scan for total count (efficient for small dataset)
        response = table.scan(Select='COUNT')
        total_movies = response['Count']
        
        # Get random offset
        skip = random.randint(0, total_movies - 1)
        
        # Scan with limit 1 and offset
        response = table.scan(
            Limit=1,
            Select='ALL_ATTRIBUTES'
        )
        
        if not response['Items']:
            raise Exception("No movie found")
            
        return response['Items'][0]
    except ClientError as e:
        logger.error(f"Error accessing DynamoDB: {str(e)}")
        raise

def generate_alternate_summary(movie_title, original_summary):
    """Generate an alternative plot summary using OpenAI."""
    try:
        client = OpenAI(
            api_key=get_openai_api_key(),
            timeout=3.0  # 3 second timeout
        )
        
        prompt = f"""Given the movie "{movie_title}", rewrite this plot summary in a different style:
        Original: {original_summary}
        
        Provide a new 2-3 sentence summary that captures the same key points but with different wording.
        """
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a movie expert who writes engaging plot summaries."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=150
        )
        
        return response.choices[0].message.content.strip()
    except Exception as e:
        logger.error(f"Error calling OpenAI API: {str(e)}")
        raise

def lambda_handler(event, context):
    """Main Lambda handler."""
    try:
        # Get random movie
        movie = get_random_movie()
        logger.info(f"Selected movie: {movie['title']}")
        
        # Generate alternative summary
        alternate_summary = generate_alternate_summary(
            movie['title'],
            movie['summary']
        )
        logger.info("Generated alternate summary successfully")
        
        # Handle Decimal serialization
        movie = json.loads(json.dumps(movie, default=str))
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'movie': movie,
                'alternate_summary': alternate_summary,
                'message': 'Successfully generated alternate summary'
            })
        }
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'message': 'Error processing request'
            })
        }